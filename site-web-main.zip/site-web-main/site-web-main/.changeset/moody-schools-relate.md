---
"flowershow": patch
---

Bump `mddb` package version to `ˆ0.2.1` to add support for Obsidian-style tags (i.e. `tags: a,b,c`).
